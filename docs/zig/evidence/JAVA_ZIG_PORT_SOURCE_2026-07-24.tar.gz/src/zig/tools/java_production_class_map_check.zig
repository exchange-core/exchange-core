const std = @import("std");

const JavaRoot = "src/main/java/exchange/core2/core";
const MapPath = "src/zig/JAVA_PRODUCTION_CLASS_MAP.md";
const ExpectedJavaFiles = 91;

const CheckError = error{
    ClassMapMismatch,
    UnexpectedJavaFileCount,
};

const Counters = struct {
    java_files: usize = 0,
    invalid_mappings: usize = 0,
};

pub fn main(init: std.process.Init) !void {
    var gpa: std.heap.DebugAllocator(.{}) = .init;
    defer _ = gpa.deinit();
    const allocator = gpa.allocator();

    const map = try std.Io.Dir.cwd().readFileAlloc(
        init.io,
        MapPath,
        allocator,
        .unlimited,
    );
    defer allocator.free(map);

    var stderr_buffer: [4096]u8 = undefined;
    var stderr_writer = std.Io.File.stderr().writer(init.io, &stderr_buffer);
    const stderr = &stderr_writer.interface;

    var counters: Counters = .{};
    try checkDirectory(
        allocator,
        init.io,
        JavaRoot,
        map,
        stderr,
        &counters,
    );

    const mapped_rows = countMappedRows(map);
    if (counters.java_files != ExpectedJavaFiles) {
        try stderr.print(
            "expected {d} Java production files, found {d}\n",
            .{ ExpectedJavaFiles, counters.java_files },
        );
        try stderr.flush();
        return CheckError.UnexpectedJavaFileCount;
    }
    if (mapped_rows != counters.java_files or counters.invalid_mappings != 0) {
        try stderr.print(
            "class map rows={d}, Java files={d}, invalid mappings={d}\n",
            .{ mapped_rows, counters.java_files, counters.invalid_mappings },
        );
        try stderr.flush();
        return CheckError.ClassMapMismatch;
    }
}

fn checkDirectory(
    allocator: std.mem.Allocator,
    io: std.Io,
    path: []const u8,
    map: []const u8,
    stderr: *std.Io.Writer,
    counters: *Counters,
) !void {
    var dir = try std.Io.Dir.cwd().openDir(io, path, .{ .iterate = true });
    defer dir.close(io);

    var iterator = dir.iterate();
    while (try iterator.next(io)) |entry| {
        switch (entry.kind) {
            .directory => {
                const child = try std.fmt.allocPrint(
                    allocator,
                    "{s}/{s}",
                    .{ path, entry.name },
                );
                defer allocator.free(child);
                try checkDirectory(
                    allocator,
                    io,
                    child,
                    map,
                    stderr,
                    counters,
                );
            },
            .file => {
                if (!std.mem.endsWith(u8, entry.name, ".java")) continue;
                counters.java_files += 1;
                const needle = try std.fmt.allocPrint(
                    allocator,
                    "| `{s}` |",
                    .{entry.name},
                );
                defer allocator.free(needle);
                const occurrences = countOccurrences(map, needle);
                if (occurrences != 1) {
                    counters.invalid_mappings += 1;
                    try stderr.print(
                        "{s}/{s}: expected one class-map row, found {d}\n",
                        .{ path, entry.name, occurrences },
                    );
                }
            },
            else => {},
        }
    }
}

fn countOccurrences(haystack: []const u8, needle: []const u8) usize {
    var count: usize = 0;
    var cursor: usize = 0;
    while (std.mem.indexOfPos(u8, haystack, cursor, needle)) |index| {
        count += 1;
        cursor = index + needle.len;
    }
    return count;
}

fn countMappedRows(map: []const u8) usize {
    var count: usize = 0;
    var lines = std.mem.splitScalar(u8, map, '\n');
    while (lines.next()) |line| {
        if (std.mem.startsWith(u8, line, "| `") and
            std.mem.indexOf(u8, line, ".java` |") != null)
        {
            count += 1;
        }
    }
    return count;
}
