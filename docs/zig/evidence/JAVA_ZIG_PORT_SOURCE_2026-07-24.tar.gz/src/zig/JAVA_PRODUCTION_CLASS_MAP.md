# Java production class → Zig responsibility map

Updated: 2026-07-24

Scope: every one of the 91 production `.java` files under
`src/main/java/exchange/core2/core`.

This is the class-level companion to `MIGRATION_COVERAGE.md`. “Closed” means
the Java class's externally observable responsibility is owned by the named
Zig modules and participates in the verification gates. “Intentional native
divergence” means a JVM representation or mechanism is not reproduced
class-for-class; its observable contract is implemented at the stated Zig
boundary. There are no current missing or partially implemented rows.

## Core facades and events

| Java production class | Zig owner | Status and responsibility |
| --- | --- | --- |
| `ExchangeApi.java` | `exchange_api.zig`, `exchange_api_sharded.zig`, `exchange_orchestrator.zig`, `api_command.zig` | Closed — synchronous, asynchronous, batched, callback, binary, report, persistence, timestamp, and result-ownership entry points. |
| `ExchangeCore.java` | `exchange_core.zig`, `exchange_api_sharded.zig`, `exchange_runtime.zig`, `sharded_pipeline.zig` | Closed — lifecycle, admission, grouping, journaling, processor orchestration, shutdown, and fatal settlement. |
| `IEventsHandler.java` | `simple_events_processor.zig`, `events.zig` | Closed — command, trade, reject, reduce, and order-book callback contracts with borrowed callback lifetime. |
| `SimpleEventsProcessor.java` | `simple_events_processor.zig` | Closed — matcher-event translation, callback ordering, ownership, and error propagation. |

## Common domain model

| Java production class | Zig owner | Status and responsibility |
| --- | --- | --- |
| `BalanceAdjustmentType.java` | `common.zig` | Closed — adjustment and suspend adjustment discriminants. |
| `CoreSymbolSpecification.java` | `common.zig`, `java_snapshot_body.zig` | Closed — symbol economics, validation, hashing, and Java persistence decoding. |
| `CoreWaitStrategy.java` | `config.zig`, `runtime_queue.zig`, `sharded_pipeline.zig` | Closed — public strategy selection and equivalent blocking/yield/spin runtime behavior. |
| `IOrder.java` | `common.zig`, `orderbook_naive.zig`, `orderbook_direct.zig` | Closed — immutable order view contract used by reports, hashing, and snapshots. |
| `L2MarketData.java` | `events.zig`, `orderbook_naive.zig`, `orderbook_direct.zig` | Closed — bounded/full asks and bids, totals, timestamps, and ownership. |
| `MatcherEventType.java` | `events.zig` | Closed — trade, reject, and reduce event kinds. |
| `MatcherTradeEvent.java` | `events.zig`, `simple_events_processor.zig` | Closed — event chain fields, allocation, cloning, traversal, and destruction. |
| `Order.java` | `common.zig`, `java_report_wire.zig` | Closed — report-facing order representation and Java wire order. |
| `OrderAction.java` | `common.zig`, `java_report_producer.zig` | Closed — ask/bid semantics and exact-Java identity-assisted hashing. |
| `OrderType.java` | `common.zig`, `orderbook_naive.zig`, `orderbook_direct.zig` | Closed — GTC, IOC, IOC-budget, FOK, and FOK-budget execution semantics. |
| `PositionDirection.java` | `common.zig`, `user_profile.zig`, `risk.zig` | Closed — empty/long/short position direction and margin accounting. |
| `StateHash.java` | `java_hash32.zig`, `java_report_producer.zig`, domain `stateHash` methods | Closed — exact Java 32-bit composition with an explicit process identity context and independent native fingerprints. |
| `SymbolPositionRecord.java` | `user_profile.zig`, `risk.zig`, `java_report_wire.zig` | Closed — pending/open volume, profit, margin, settlement, reports, and persistence. |
| `SymbolType.java` | `common.zig`, `risk.zig` | Closed — exchange-pair and futures-contract risk paths. |
| `UserProfile.java` | `user_profile.zig`, `risk.zig` | Closed — accounts, positions, transaction tracking, status, hashing, and persisted encounter history. |
| `UserStatus.java` | `common.zig`, `user_profile.zig`, `java_report_producer.zig` | Closed — active/suspended transitions and exact-Java identity-assisted hashing. |

## Typed API commands

| Java production class | Zig owner | Status and responsibility |
| --- | --- | --- |
| `ApiAddUser.java` | `api_command.zig`, API facades | Closed — add-user fields, timestamps, sync/async/callback publication, and result mapping. |
| `ApiAdjustUserBalance.java` | `api_command.zig`, API facades | Closed — currency, amount, transaction ID, adjustment type, timestamp, and result mapping. |
| `ApiBinaryDataCommand.java` | `api_command.zig`, `binary_payload.zig`, API facades | Closed — owned binary command publication, framing, and terminal completion. |
| `ApiCancelOrder.java` | `api_command.zig`, API facades | Closed — order/user/symbol identity, timestamps, matcher events, and result mapping. |
| `ApiCommand.java` | `api_command.zig` | Closed — exhaustive tagged command union and Java-field translation. |
| `ApiMoveOrder.java` | `api_command.zig`, API facades | Closed — price mutation, timestamps, matcher events, and result mapping. |
| `ApiNop.java` | `api_command.zig`, API facades | Closed — barrier semantics, timestamps, and Java callback allowlist behavior. |
| `ApiOrderBookRequest.java` | `api_command.zig`, API facades | Closed — symbol/depth request, timestamps, and L2 ownership. |
| `ApiPersistState.java` | `api_command.zig`, API facades | Closed — adjacent matching/risk persistence pair and merged result. |
| `ApiPlaceOrder.java` | `api_command.zig`, API facades | Closed — all order fields, timestamps, holds, matching, and events. |
| `ApiReduceOrder.java` | `api_command.zig`, API facades | Closed — size reduction, timestamps, release accounting, and events. |
| `ApiReset.java` | `api_command.zig`, API facades, kernel/runtime reset paths | Closed — global book, risk, user, binary, price, fee, grouping, and pending-state reset. |
| `ApiResumeUser.java` | `api_command.zig`, API facades | Closed — status transition, timestamps, and duplicate-edge result. |
| `ApiSuspendUser.java` | `api_command.zig`, API facades | Closed — status transition, open-position guard, timestamps, and duplicate-edge result. |

## Binary commands and reports

| Java production class | Zig owner | Status and responsibility |
| --- | --- | --- |
| `BatchAddAccountsCommand.java` | `binary_commands.zig`, `java_binary_wire.zig`, `binary_frames.zig` | Closed — exact Java payload, bounded framing, sharded broadcast, and account application. |
| `BatchAddSymbolsCommand.java` | `binary_commands.zig`, `java_binary_wire.zig`, `binary_frames.zig` | Closed — exact Java payload, bounded framing, sharded broadcast, and symbol application. |
| `BinaryCommandType.java` | `binary_payload.zig`, `binary_commands.zig` | Closed — built-in command codes and unknown-code failure. |
| `BinaryDataCommand.java` | `binary_payload.zig`, `binary_frames.zig`, `binary_commands.zig` | Closed — binary command envelope, LZ4/raw decoding, transfer assembly, and execution. |
| `ApiReportQuery.java` | `api_command.zig`, `report_query_envelope.zig`, API facades | Closed — typed and owned arbitrary report-query publication. |
| `ReportQueriesHandler.java` | `exchange_kernel.zig`, `custom_report_pipeline.zig`, `report_registry.zig` | Closed — per-shard query dispatch, section transport, reducer order, and cleanup. |
| `ReportQuery.java` | `report_query_envelope.zig`, `report_registry.zig` | Closed — built-in and registered custom query contracts with allocator-bound ownership. |
| `ReportResult.java` | `java_report_wire.zig`, `custom_report_pipeline.zig` | Closed — exact built-in reduction and typed custom reduction. |
| `ReportType.java` | `java_report_wire.zig`, `report_registry.zig` | Closed — reserved codes, duplicate rejection, and unknown-code handling. |
| `SingleUserReportQuery.java` | `java_report_producer.zig`, `java_report_wire.zig` | Closed — user lookup and per-matching/per-risk Java sections. |
| `SingleUserReportResult.java` | `java_report_wire.zig`, API report extraction | Closed — status, accounts, positions, orders, query status, and deterministic reduction. |
| `StateHashReportQuery.java` | `java_report_producer.zig`, `java_report_wire.zig` | Closed — requested submodules and exact section production. |
| `StateHashReportResult.java` | `java_report_producer.zig`, `java_report_wire.zig`, `java_hash32.zig` | Closed — Java wrapping reduction and explicit JVM identity capability. |
| `TotalCurrencyBalanceReportQuery.java` | `java_report_producer.zig`, `java_report_wire.zig` | Closed — risk and matching balance sections. |
| `TotalCurrencyBalanceReportResult.java` | `java_report_wire.zig`, `risk.zig` | Closed — account, fee, adjustment, suspend, order, and open-interest reduction. |

## Command protocol

| Java production class | Zig owner | Status and responsibility |
| --- | --- | --- |
| `CommandResultCode.java` | `cmd.zig` | Closed — complete result-code values, severity ordering, and merged persistence results. |
| `OrderCommand.java` | `cmd.zig`, `events.zig` | Closed — command fields, copy/reset rules, matcher chain/L2 ownership, and result completion. |
| `OrderCommandType.java` | `cmd.zig` | Closed — command codes, mutability/journaling predicate, shutdown/reset/global classification. |

## Configuration

| Java production class | Zig owner | Status and responsibility |
| --- | --- | --- |
| `ExchangeConfiguration.java` | `config.zig` | Closed — composed Java-shaped configuration adapter and validation. |
| `InitialStateConfiguration.java` | `config.zig`, persistence startup paths | Closed — clean start, snapshot, journal, sequence, exchange ID, and strict-missing policy. |
| `LoggingConfiguration.java` | `config.zig` | Closed — logging flags are preserved as typed configuration metadata; JVM logger plumbing is a native divergence. |
| `OrdersProcessingConfiguration.java` | `config.zig`, `risk.zig` | Closed — risk-processing and margin-trading modes. |
| `PerformanceConfiguration.java` | `config.zig`, `runtime_queue.zig`, `sharded_pipeline.zig` | Closed — queue size, topology, group sizing/time, L2 policy/depth, wait strategy, and naive/direct selection. Java object factories for threads, compressors, and books are represented by Zig-owned lifecycle, the exact wire codec, and the closed built-in book enum; injecting JVM objects is an intentional native divergence. |
| `ReportsQueriesConfiguration.java` | `config.zig`, `report_registry.zig`, `custom_report_pipeline.zig` | Closed — standard reports, custom registration, reserved codes, constructors, ownership, and digest binding. |
| `SerializationConfiguration.java` | `config.zig`, `serialization_processor.zig` | Closed — dummy/disk presets, journaling switch, and owned custom processor factory. |

## Order books

| Java production class | Zig owner | Status and responsibility |
| --- | --- | --- |
| `IOrderBook.java` | `orderbook_naive.zig`, `orderbook_direct.zig`, `exchange_kernel.zig` | Closed — place/move/cancel/reduce, L2, user orders, streams/views, validation, hashing, and snapshot contract. |
| `OrderBookDirectImpl.java` | `orderbook_direct.zig` | Closed — indexed linked price levels, object pools, matching, mutation, OOM atomicity, validation, and snapshots. Zig uses native arrays/hash indexes rather than Java ART nodes. |
| `OrderBookEventsHelper.java` | `events.zig`, both order books | Closed — trade/reject/reduce allocation and chain ordering. |
| `OrderBookNaiveImpl.java` | `orderbook_naive.zig` | Closed — reference price-level/order lists and full command semantics. |
| `OrdersBucketNaive.java` | `orderbook_naive.zig` | Closed — FIFO price-bucket matching, volume accounting, removal, and validation. |
| `OrdersSpliterator.java` | both order books, `java_report_producer.zig` | Intentional native divergence — Java streams are replaced by deterministic ask-then-bid and FIFO slice traversal used by reports and hashes. |

## Processor ecosystem

| Java production class | Zig owner | Status and responsibility |
| --- | --- | --- |
| `BinaryCommandsProcessor.java` | `binary_frames.zig`, `binary_payload.zig`, `exchange_kernel.zig` | Closed — bounded assembly, broadcast, exact report/command dispatch, persistence, and reset. |
| `DisruptorExceptionHandler.java` | runtime error unions, poison/fatal records, lifecycle teardown | Intentional native divergence — one immutable fatal frontier, wake-all, suffix suppression, and deterministic join replace Disruptor callbacks. |
| `GroupingProcessor.java` | `grouping_processor.zig`, `sharded_pipeline.zig` | Closed — group IDs, time/size boundaries, L2 service flags, control gating, and journal/result frontiers. |
| `MatchingEngineRouter.java` | `exchange_kernel.zig`, `exchange_core_sharded.zig`, `sharded_pipeline.zig` | Closed — symbol ownership, binary broadcast, persistence, reports, reset, L2, and matching stage. |
| `ResultsHandler.java` | API/runtime result sinks, raw observer, `simple_events_processor.zig` | Closed — grouping-control suppression and raw → reduced → simple-event publication ordering after journal acknowledgement. |
| `RiskEngine.java` | `risk.zig`, `exchange_kernel.zig`, `sharded_pipeline.zig` | Closed — R1 admission, margin/fees, cached prices, binary commands/reports, persistence, and staged atomic R2 release. |
| `SharedPool.java` | allocator-owned response/event chains, `locked_allocator.zig` | Intentional native divergence — explicit allocator ownership and non-aliasing replace the JVM object pool while preserving bounded lifetime. |
| `SimpleEventHandler.java` | `simple_events_processor.zig` | Closed — callback dispatch and ownership contract. |
| `SymbolSpecificationProvider.java` | `risk.zig`, `common.zig` | Closed — symbol storage, lookup, reset, hashing, binary load, and persistence. |
| `TwoStepMasterProcessor.java` | `sharded_pipeline.zig` | Closed — stable R1 frontier, prior-group dependency, stage coordination, and exception propagation. |
| `TwoStepSlaveProcessor.java` | `sharded_pipeline.zig` | Closed — delayed R2 prepare/commit, all-shard atomicity, group completion, and terminal quiescence. |
| `UserProfileService.java` | `user_profile.zig`, `risk.zig` | Closed — add/suspend/resume/reset, lookup, hashing, report views, and persistence. |
| `WaitSpinningHelper.java` | `runtime_queue.zig`, `sharded_pipeline.zig` | Intentional native divergence — Zig mutex/condition and configured outer wait strategies implement bounded progress without Disruptor sequences. |

## Persistence processors

| Java production class | Zig owner | Status and responsibility |
| --- | --- | --- |
| `DiskSerializationProcessor.java` | native snapshot/journal modules plus Java converters | Closed — XCM2/XCJ3 durability and offline Chronicle `.ecs`/`.ecj` conversion with native restore/replay verification. |
| `DiskSerializationProcessorConfiguration.java` | `config.zig`, `persistence_paths.zig` | Closed — storage root, naming, topology, journal/snapshot policy, and limits. |
| `DummySerializationProcessor.java` | `serialization_processor.zig`, disabled persistence paths | Closed — explicit no-op backend and fail-closed persistence-required startup. |
| `ISerializationProcessor.java` | `serialization_processor.zig` | Closed — owned type-erased factory, startup restore/replay state, per-module store, journal, shutdown, destruction, and typed failures. |
| `JournalDescriptor.java` | `persistence_descriptors.zig`, `journal.zig` | Closed — partition ranges, sequence/timestamp frontiers, links, and durable registration. |
| `SnapshotDescriptor.java` | `persistence_descriptors.zig`, `sharded_snapshot_store.zig` | Closed — topology-aware snapshots, module instances, parent/journal links, and commit boundary. |

## JVM utilities

| Java production class | Zig owner | Status and responsibility |
| --- | --- | --- |
| `AffinityThreadFactory.java` | lifecycle-owned runtime and grouped worker creation | Intentional native divergence — Zig owns worker creation/join; configured topology and wait strategy remain observable, JVM thread naming/affinity objects do not cross the native boundary. |
| `CoreArithmeticUtils.java` | `risk.zig`, order books, `java_hash32.zig` | Closed — fees, holds, margin, P&L, wrapping Java report math, and checked native arithmetic. |
| `HashingUtils.java` | `java_hash32.zig`, `java_report_producer.zig`, domain hash methods | Closed — Java list/stream/map/hash composition and native fingerprints remain isolated. |
| `ReflectionUtils.java` | tagged unions, compile-time switches, `report_registry.zig` | Intentional native divergence — compile-time/type-erased constructors replace Java reflection with typed duplicate and constructor errors. |
| `SerializationUtils.java` | Java wire readers/writers, snapshot/journal codecs, Eclipse history codecs | Closed — primitive collections, nullable values, LZ4 framing, Chronicle bodies, and native persistence codecs. |
| `UnsafeUtils.java` | `cmd.zig` result merging and explicit mutable command methods | Intentional native divergence — typed mutation replaces JVM `Unsafe` field compare-and-set while preserving result-code merge behavior. |
| `Utils.java` | Zig standard library plus local bounded helpers | Intentional native divergence — power-of-two, sorting, optional, and collection helpers are expressed through native checked APIs. |

## Verification linkage

- `EXCHANGE_API_PARITY_AUDIT.md` maps every public Java `ExchangeApi`
  declaration to a Zig entry point, observable contract, and executable test.
- `PROCESSOR_PARITY_DECOMPOSITION.md` records processor timing, ownership,
  failure, and persistence boundaries.
- `MIGRATION_COVERAGE.md` records the current Debug, ReleaseSafe, Java fixture,
  audit, format, capacity, and repository-wide gates.
- The class-map coverage check compares this file with the 91 production Java
  source basenames and fails if either side has an unmapped class.
